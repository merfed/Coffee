using System;

namespace WarLib.MPQ.Signing
{
	public class WeakSign
	{
		public WeakSign()
		{
		}
	}
}

