# Blizzard FreeDesktop MIME Types
This repository contains a set of FreeDesktop-compliant MIME type definitions for file formats used by Blizzard Entertainment. While fairly useless on their own, they are very useful if you're developing software that interacts with these formats and needs to integrate with desktop environments.
