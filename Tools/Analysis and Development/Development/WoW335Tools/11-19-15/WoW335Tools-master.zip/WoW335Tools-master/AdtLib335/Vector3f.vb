﻿Public Class Vector3f
    Public Property X As Single
    Public Property Y As Single
    Public Property Z As Single

    Public Sub New(pX As Single, pY As Single, pZ As Single)
        X = pX
        Y = pY
        Z = pZ
    End Sub
End Class
