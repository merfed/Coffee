﻿Public Class Plane
    Public Property Height As Int16(,)
End Class