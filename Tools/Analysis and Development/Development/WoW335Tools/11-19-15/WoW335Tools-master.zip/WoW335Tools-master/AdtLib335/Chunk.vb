﻿Public Interface Chunk
    Sub Read(ByRef BinaryReader As IO.BinaryReader, ChunkSize As UInt32)
End Interface
