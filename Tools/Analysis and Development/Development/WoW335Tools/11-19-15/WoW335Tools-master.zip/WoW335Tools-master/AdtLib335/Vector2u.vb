﻿Public Class Vector2u
    Public Property X As UInt32
    Public Property Y As UInt32

    Public Sub New(pX As UInt32, pY As UInt32)
        X = pX
        Y = pY
    End Sub
End Class
