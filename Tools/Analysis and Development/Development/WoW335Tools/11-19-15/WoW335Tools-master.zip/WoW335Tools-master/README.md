# WoW335Tools
Tools/Libraries for reading WoW 3.3.5 files.
I'll plan to saving later, but i can't tell you when.

At this moment you can read .adt and .wdt files.
