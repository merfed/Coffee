﻿namespace WDBXEditor.Archives.CASC.Structures
{
    public struct IndexEntry
    {
        public ushort Index { get; set; }
        public uint Offset  { get; set; }
        public uint Size    { get; set; }
    }
}
