﻿namespace WDBXEditor.Archives.CASC.Structures
{
    public struct EncodingEntry
    {
        public byte[][] Keys { get; set; }
        public uint Size     { get; set; }
    }
}
