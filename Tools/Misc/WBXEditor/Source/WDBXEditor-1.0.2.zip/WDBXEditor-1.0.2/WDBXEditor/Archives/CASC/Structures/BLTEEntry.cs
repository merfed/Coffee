﻿namespace WDBXEditor.Archives.CASC.Structures
{
    public class BLTEEntry
    {
        public BLTEChunk[] Chunks { get; set; }
    }
}
