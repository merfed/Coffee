﻿namespace WDBXEditor.Archives.CASC.Structures
{
    public struct BLTEChunk
    {
        public long CompressedSize { get; set; }
        public long UncompressedSize { get; set; }
    }
}
