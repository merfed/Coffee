#ifndef FALLBACK_H
#define FALLBACK_H
#include "structures.h"

short get_RealID(short ID, BCM2 model);

#endif
