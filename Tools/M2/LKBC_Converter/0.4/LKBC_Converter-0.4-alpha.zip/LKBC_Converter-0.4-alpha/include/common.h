#ifndef COMMON_H
#define COMMON_H
#include "structures.h"

extern char *model_name;
extern size_t name_length;
extern int classic;

#endif
