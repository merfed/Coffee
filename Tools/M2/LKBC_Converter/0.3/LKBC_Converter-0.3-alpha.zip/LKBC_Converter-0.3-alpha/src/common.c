/**
 * @file
 */
#include <stdio.h>
#include <string.h>
#include "common.h"

char *model_name;
size_t name_length;
