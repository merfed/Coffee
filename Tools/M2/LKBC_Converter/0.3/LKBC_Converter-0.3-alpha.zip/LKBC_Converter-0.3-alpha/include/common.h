#ifndef COMMON_H
#define COMMON_H
#include "structures.h"

extern char *model_name;
extern size_t name_length;
int isBugged(int flags);

#endif
