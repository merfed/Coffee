#ifndef FALLBACK_H
#define FALLBACK_H
#include "structures.h"

int get_RealPos(int pos, LKModelAnimation *animations);
short get_RealID(short ID, BCM2 model);

#endif
