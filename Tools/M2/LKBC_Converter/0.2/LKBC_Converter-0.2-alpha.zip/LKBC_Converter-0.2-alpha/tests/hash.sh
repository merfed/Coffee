#!/bin/sh
./lkbc_converter $1|md5sum
