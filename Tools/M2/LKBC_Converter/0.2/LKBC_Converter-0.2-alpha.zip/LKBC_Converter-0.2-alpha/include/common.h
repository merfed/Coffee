#ifndef COMMON_H
#define COMMON_H
#include "structures.h"

extern char *model_name;
int isBugged(int flags);

#endif
