# GNOME BLP Thumbnailer

Thumbnail generator for BLP image files.
This program generates thumbnails for the GNOME desktop environment for binary BLP images, using [libwarcraft](https://github.com/Nihlus/libwarcraft).