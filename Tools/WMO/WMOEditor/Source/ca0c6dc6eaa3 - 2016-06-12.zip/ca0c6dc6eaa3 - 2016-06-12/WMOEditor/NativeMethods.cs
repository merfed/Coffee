﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace WMOEditor
{
    public static class NativeMethods
    {
        [DllImport("User32.dll")]
        public static extern void GetKeyboardState(byte[] buffer);
    }
}
