﻿namespace WoWEditor6.Scene
{
    class OrthoCamera
    {
    }
}
