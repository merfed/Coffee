﻿
namespace WoWEditor6.Scene.Texture
{
    /// <summary>
    /// TODO: Not yet implemented (not sure if it even makes sense)
    /// </summary>
    class TextureArrayManager
    {
    }
}
