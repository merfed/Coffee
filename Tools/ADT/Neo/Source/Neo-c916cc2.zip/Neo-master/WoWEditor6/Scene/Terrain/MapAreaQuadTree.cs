﻿
namespace WoWEditor6.Scene.Terrain
{
    class MapAreaQuadTree
    {
    }
}
