﻿namespace WoWEditor6.Scene
{
    enum AppState
    {
        Idle,
        Splash,
        FileSystemInit,
        MapSelect,
        EntrySelect,
        LoadingScreen,
        World
    }
}
