﻿
namespace WoWEditor6.IO
{
    enum FileDataVersion
    {
        Warlords,
        Mists,
        Cataclysm,
        Lichking,
        Crusade,
        Classic
    }
}
