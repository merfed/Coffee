﻿using System.Windows.Forms;

namespace WoWEditor6.UI.Dialogs
{
    public partial class GameObjectEditor : Form
    {
        public GameObjectEditor()
        {
            InitializeComponent();
        }
    }
}
