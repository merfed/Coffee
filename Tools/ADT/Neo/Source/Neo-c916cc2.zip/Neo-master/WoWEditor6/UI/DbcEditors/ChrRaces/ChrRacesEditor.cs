﻿using System.Windows.Forms;

namespace WoWEditor6.UI.DbcEditors.ChrRaces
{
    public partial class ChrRacesEditor : Form
    {
        public ChrRacesEditor()
        {
            InitializeComponent();
        }
    }
}
