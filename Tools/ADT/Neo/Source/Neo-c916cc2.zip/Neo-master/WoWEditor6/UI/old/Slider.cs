﻿using System;
using SharpDX.Direct2D1;

namespace WoWEditor6.UI.Components
{
    class Slider : IComponent
    {
        public void OnRender(RenderTarget target)
        {
            throw new NotImplementedException();
        }

        public void OnMessage(Message message)
        {
            throw new NotImplementedException();
        }
    }
}
