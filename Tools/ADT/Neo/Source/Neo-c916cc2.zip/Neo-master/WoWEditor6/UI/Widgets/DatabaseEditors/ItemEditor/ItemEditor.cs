﻿using System.Windows.Forms;

namespace WoWEditor6.UI.Dialogs
{
    public partial class ItemEditor : Form
    {
        public ItemEditor()
        {
            InitializeComponent();
        }
    }
}
