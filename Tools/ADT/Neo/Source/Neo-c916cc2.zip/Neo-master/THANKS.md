## Neo Editor Thanks & Credits

Neo is a map editor for World of Warcraft mainly written in C#. A special thanks is extended to Cromon for all of his initial work on Neo and for leaving it open source so it may continue being improved and added on to.

Thank you to everyone listed below for your various commits, patches, code fixes and contributions. These are in alphabetical order, Please let us know if we missed your contribution!

#### Contributors

- Barncastle
- Cromon _(Neo Creator)_
- Dashker
- Deep6ixed
- Desmond
- Dokman
- Kaev
- Luzifix
- MajorCyto
- Neccta
- Relaxok
- Skarn
- Steff
- Tripleslash
- Westtunger
