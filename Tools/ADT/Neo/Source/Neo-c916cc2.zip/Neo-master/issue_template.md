**Description**:

**Current behaviour**: Tell us what happens

**Expected behaviour**: Tell us what should happen instead

**Steps to reproduce the problem**:

1. 
2. 
3. 

**Branch(es)**:  

**Neo hash/commit**:    

**WoW Version**:

**Operating system**:  

[//]: # (This template is for problem reports, for other type of reports edit it accordingly)
[//]: # (If this is a crash report, include the crashlog with https://gist.github.com/)