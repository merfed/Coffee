# ADTConvert
The ADTConverter can convert the World of Warcraft ADT Format form LK(3.3.5) to WoD(6.x.x)

