Hi :)

When unzipping the mdx, the name gets somewhat corrupted and doesn't pass mdx > M2 conversion anymore. 
Just rename the file and it'll be ok :)

Mjolln�